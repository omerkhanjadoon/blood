<?php include('headfile.php'); ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div style="margin:0px auto;text-align: center;"><img src="images/construction.png" style="width:300px;" alt="">
                        <h1>Under Construction !</h1>

                        <h3>All messages will be displayed here</h3>
                        </div>
                        <br><br><br>
                        <div style="height: 30px;background: url(images/clip.png);"></div>
                       
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 UOH Blood Donation Society. All rights reserved.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- end of container -->
                </div>
            </div>
            <!-- END MAIN CONTENT-->

            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <script src="vendor/jquery-3.2.1.min.js"></script>
 <!-- Bootstrap JS-->
    <script src="js/main2.js"></script>
    
    <!-- Bootstrap JS-->
    
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    
    <script src="vendor/animsition/animsition.min.js"></script>

    <!-- Main JS-->
    
<script src="js/main.js"></script>

   

</body>

</html>
<!-- end document-->
